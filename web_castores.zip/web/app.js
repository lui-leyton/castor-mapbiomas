/* Castor en Magallanes — mapa, paneles, ilustraciones y visor multitemporal.
   Sin framework ni build: se arrastra la carpeta a Cloudflare Pages y funciona. */

'use strict';

const COLOR = {
  // Paleta del mapa pensada para leerse sobre DOS fondos: la cobertura a color
  // y el mapa base oscuro. Por eso los poligonos llevan doble trazo (casing):
  // uno oscuro por fuera y uno claro por dentro, visible en ambos casos.
  impacto: '#4C9A6B',          // relleno translucido
  impactoBorde: '#0E2A16',     // trazo exterior, oscuro
  impactoBordeInt: '#8FD9A8',  // trazo interior, claro
  dique: '#E4322B',            // rojo
  diqueBorde: '#2A0A08',
  area: '#B5B2A8',
  sitio: '#9A7C5C',
  timaukel: '#C8B88A',
  bosque: '#3E7D4F',
  muerto: '#8C8A83',
};

const CAPAS = [
  { id: 'cobertura', rotulo: 'Cobertura MapBiomas 2024', color: '#1F8D49',
    visible: true, capas: ['cob-timaukel', 'cob-estudio'] },
  { id: 'impacto', rotulo: 'Polígonos de impacto', color: COLOR.impacto,
    visible: true, n: 241, capas: ['impacto', 'impacto-borde', 'impacto-borde-int'] },
  { id: 'diques', rotulo: 'Diques', color: COLOR.dique, visible: true, n: 806,
    capas: ['diques', 'hex-grueso', 'hex-grueso-borde', 'hex-grueso-rotulo',
            'hex-fino', 'hex-fino-borde', 'hex-fino-rotulo'] },
  { id: 'area', rotulo: 'Área de estudio', color: COLOR.area, visible: true, hueco: true },
  { id: 'timaukel', rotulo: 'Comuna de Timaukel', color: COLOR.timaukel, visible: true, hueco: true },
  { id: 'sitios', rotulo: 'Sitios del estudio', color: COLOR.sitio, visible: false, hueco: true, n: 5 },
];

const $ = (s) => document.querySelector(s);
const crear = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };
const num = (v, d = 0) => v == null ? '—'
  : v.toLocaleString('es-CL', { minimumFractionDigits: d, maximumFractionDigits: d });

const svgNS = 'http://www.w3.org/2000/svg';
function nodo(tag, attrs, texto) {
  const e = document.createElementNS(svgNS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (texto != null) e.textContent = texto;
  return e;
}
function lienzo(w, h, titulo) {
  const s = nodo('svg', { viewBox: `0 0 ${w} ${h}`, role: 'img' });
  s.appendChild(nodo('title', {}, titulo));
  return s;
}

let mapa, metricas, diquesGeo = null, geo = {};
let paneles = [], sincronizando = false;

// Version de los assets. DEBE coincidir con el ?v= de index.html.
// Sin esto los datos quedan cacheados 24 h (ver _headers) y una actualizacion
// no llega a quien ya visito el sitio: el sintoma es ver capas o botones viejos.
const VERSION = '17';
const v = (ruta) => ruta + (ruta.includes('?') ? '&' : '?') + 'v=' + VERSION;

const ESTILO_BASE = 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json';

// Estilo de reserva, sin red: si el CDN del mapa base no responde, los datos
// propios igual se dibujan. Los GeoJSON no dependen de el.
const ESTILO_RESERVA = {
  version: 8, sources: {},
  // Los glyphs vienen del CDN: sin ellos MapLibre omite los rotulos de los
  // hexagonos. Si no hay red, se pierden los numeros pero no los poligonos.
  glyphs: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/{fontstack}/{range}.pbf',
  layers: [{ id: 'fondo', type: 'background', paint: { 'background-color': '#0E1A22' } }],
};
const ESPERA_BASE_MS = 7000;

// Relevo progresivo: hexagonos gruesos de lejos, finos a medio camino y
// diques individuales al acercarse. Los umbrales se declaran una vez y los
// usan tanto las capas como el rotulo de ayuda.
const Z_GRUESO_FINO = 11.6;
const Z_FINO_PUNTOS = 13.2;
// Escala de color por conteo: misma familia roja que los diques, porque el
// hexagono ES un dique agregado.
const ESCALA_HEX = [
  'interpolate', ['linear'], ['get', 'n'],
  1, '#F0A9A3', 5, '#E4322B', 20, '#A01D18', 60, '#5E100D',
];

/* ------------------------------------------------------------------ mapa */

function estado(texto) {
  let e = $('#mapa .estado');
  if (!texto) { if (e) e.remove(); return; }
  if (!e) { e = crear('div', 'estado'); $('#mapa').appendChild(e); }
  e.textContent = texto;
}

function iniciarMapa() {
  mapa = new maplibregl.Map({
    container: 'mapa', style: ESTILO_BASE,
    center: [-69.78, -53.77], zoom: 10.4, attributionControl: false,
  });
  mapa.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');
  mapa.addControl(new maplibregl.ScaleControl({ maxWidth: 110, unit: 'metric' }), 'bottom-left');
  mapa.addControl(new maplibregl.AttributionControl({
    compact: true,
    customAttribution: 'Datos: verdad de terreno digitalizada · Límite comunal: OpenStreetMap (ODbL) · Base: CARTO',
  }), 'bottom-right');

  estado('Cargando mapa base…');

  let listo = false;
  const arrancar = async (conBase) => {
    if (listo) return;
    listo = true;
    estado(conBase ? 'Cargando datos…' : 'Mapa base no disponible. Mostrando solo los datos…');
    try {
      await cargarCapas();
      estado(conBase ? null : 'Sin mapa base: los datos se muestran sobre fondo liso.');
      if (!conBase) setTimeout(() => estado(null), 4500);
    } catch (err) {
      estado('No se pudieron cargar los datos: ' + err.message);
    }
  };

  // Si el CDN no responde en ESPERA_BASE_MS, se cambia al estilo de reserva y
  // se dibujan los datos igual. Sin esto el sitio se queda en "Cargando".
  const reserva = setTimeout(() => {
    if (listo) return;
    mapa.once('styledata', () => arrancar(false));
    mapa.setStyle(ESTILO_RESERVA);
  }, ESPERA_BASE_MS);

  mapa.on('error', (e) => {
    const m = String((e && e.error && e.error.message) || '');
    if (!listo && /style|sprite|glyphs|fetch|network/i.test(m)) {
      clearTimeout(reserva);
      mapa.once('styledata', () => arrancar(false));
      mapa.setStyle(ESTILO_RESERVA);
    }
  });

  mapa.on('load', () => { clearTimeout(reserva); arrancar(true); });
}

async function json(ruta) {
  const r = await fetch(ruta);
  if (!r.ok) throw new Error(ruta + ' (' + r.status + ')');
  return r.json();
}

async function cargarCapas() {
  const [impacto, diques, area, sitios, timaukel] = await Promise.all([
    json(v('datos/impacto.geojson')), json(v('datos/diques.geojson')),
    json(v('datos/area_estudio.geojson')), json(v('datos/sitios.geojson')),
    json(v('datos/timaukel.geojson')).catch(() => null),
  ]);
  geo = { impacto, diques, area, sitios, timaukel };
  diquesGeo = diques;

  // Fondo de cobertura. Dos escalas: la comuna como contexto y el area de
  // estudio con mas detalle encima, porque una sola imagen no sirve para
  // ambos niveles de zoom. Se agregan primero para que queden por debajo.
  const cob = metricas && metricas.cobertura;
  if (cob) {
    ['timaukel', 'estudio'].forEach((k) => {
      const c = cob.capas[k];
      if (!c) return;
      mapa.addSource('cob-' + k, { type: 'image', url: v(c.archivo), coordinates: c.esquinas });
      mapa.addLayer({
        id: 'cob-' + k, type: 'raster', source: 'cob-' + k,
        paint: { 'raster-opacity': k === 'timaukel' ? 0.78 : 0.92 },
      });
    });
  }

  if (timaukel) {
    mapa.addSource('timaukel', { type: 'geojson', data: timaukel });
    mapa.addLayer({
      id: 'timaukel', type: 'line', source: 'timaukel',
      paint: { 'line-color': COLOR.timaukel, 'line-width': 1.3, 'line-opacity': 0.55 },
    });
  }

  mapa.addSource('area', { type: 'geojson', data: area });
  mapa.addLayer({
    id: 'area', type: 'line', source: 'area',
    paint: { 'line-color': COLOR.area, 'line-width': 1.4, 'line-dasharray': [3, 2], 'line-opacity': 0.75 },
  });

  mapa.addSource('sitios', { type: 'geojson', data: sitios });
  mapa.addLayer({
    id: 'sitios', type: 'line', source: 'sitios', layout: { visibility: 'none' },
    paint: { 'line-color': COLOR.sitio, 'line-width': 1.6, 'line-opacity': 0.85 },
  });

  mapa.addSource('impacto', { type: 'geojson', data: impacto });
  mapa.addLayer({
    id: 'impacto', type: 'fill', source: 'impacto',
    paint: { 'fill-color': COLOR.impacto, 'fill-opacity': 0.34 },
  });
  mapa.addLayer({
    id: 'impacto-borde', type: 'line', source: 'impacto',
    paint: { 'line-color': COLOR.impactoBorde, 'line-width': 2.2, 'line-opacity': 0.85 },
  });
  mapa.addLayer({
    id: 'impacto-borde-int', type: 'line', source: 'impacto',
    paint: { 'line-color': COLOR.impactoBordeInt, 'line-width': 0.9, 'line-opacity': 0.95 },
  });

  // --- hexagonos de diques ---
  const hx = metricas && metricas.hexagonos;
  if (hx) {
    const niveles = [
      ['hex-grueso', hx.grueso, 0, Z_GRUESO_FINO],
      ['hex-fino', hx.fino, Z_GRUESO_FINO, Z_FINO_PUNTOS],
    ];
    for (const [id, cfg, zmin, zmax] of niveles) {
      if (!cfg) continue;
      const datos = await json(v(cfg.archivo));
      mapa.addSource(id, { type: 'geojson', data: datos });
      mapa.addLayer({
        id, type: 'fill', source: id, minzoom: zmin, maxzoom: zmax,
        paint: {
          'fill-color': ESCALA_HEX,
          // El hexagono se desvanece al acercarse al relevo: asi el poligono
          // de impacto que hay debajo asoma antes del corte, y pasar al nivel
          // siguiente deja de ser un parpadeo.
          'fill-opacity': ['interpolate', ['linear'], ['zoom'],
                           zmax - 1.6, 0.68, zmax, 0.38],
        },
      });
      mapa.addLayer({
        id: id + '-borde', type: 'line', source: id, minzoom: zmin, maxzoom: zmax,
        paint: { 'line-color': '#2A0A08', 'line-width': 1, 'line-opacity': 0.75 },
      });
      mapa.addLayer({
        id: id + '-rotulo', type: 'symbol', source: id,
        minzoom: zmin, maxzoom: zmax,
        layout: {
          'text-field': ['to-string', ['get', 'n']],
          'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
          'text-size': ['interpolate', ['linear'], ['zoom'], 9, 10, 13, 14],
          'text-allow-overlap': true,
        },
        paint: {
          'text-color': '#FFFFFF',
          'text-halo-color': '#2A0A08',
          'text-halo-width': 1.4,
        },
      });
    }
  }

  mapa.addSource('diques', { type: 'geojson', data: diques });
  mapa.addLayer({
    id: 'diques', type: 'circle', source: 'diques', minzoom: Z_FINO_PUNTOS,
    paint: {
      'circle-radius': ['interpolate', ['linear'], ['zoom'], 9, 2.8, 12, 4.2, 15, 6.5],
      'circle-color': COLOR.dique, 'circle-opacity': 0.95,
      // El aro existe en todos los zoom: sobre la cobertura clara un punto
      // rojo sin borde se funde con las clases calidas.
      'circle-stroke-width': ['interpolate', ['linear'], ['zoom'], 9, 0.6, 13, 1.2],
      'circle-stroke-color': COLOR.diqueBorde,
    },
  });

  mapa.on('click', 'impacto', (e) => mostrarFicha(e.features[0]));
  mapa.on('mouseenter', 'impacto', () => { mapa.getCanvas().style.cursor = 'pointer'; });
  mapa.on('mouseleave', 'impacto', () => { mapa.getCanvas().style.cursor = ''; });

  construirCapas();
  construirNotaHex();
  construirLeyendaCobertura();
  construirSitios(sitios);
  encuadrar(area);
}

function limites(g) {
  const b = new maplibregl.LngLatBounds();
  const rec = (c) => Array.isArray(c[0]) ? c.forEach(rec) : b.extend(c);
  g.features.forEach((f) => rec(f.geometry.coordinates));
  return b;
}
const encuadrar = (g) => mapa.fitBounds(limites(g), { padding: 44, duration: 0 });

/* ------------------------------------------------------ punto en poligono */

function dentro(pt, g) {
  const polys = g.type === 'Polygon' ? [g.coordinates]
    : g.type === 'MultiPolygon' ? g.coordinates : [];
  for (const poly of polys) {
    let en = false;
    for (let a = 0; a < poly.length; a++) {
      const anillo = poly[a];
      let cruza = false;
      for (let i = 0, j = anillo.length - 1; i < anillo.length; j = i++) {
        const [xi, yi] = anillo[i], [xj, yj] = anillo[j];
        if ((yi > pt[1]) !== (yj > pt[1]) &&
            pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) cruza = !cruza;
      }
      if (a === 0) { if (!cruza) break; en = true; }
      else if (cruza) { en = false; break; }
    }
    if (en) return true;
  }
  return false;
}

function contarDiques(g) {
  if (!diquesGeo) return null;
  let n = 0;
  for (const d of diquesGeo.features) if (dentro(d.geometry.coordinates, g)) n++;
  return n;
}

const fila = (a, b) => `<div class="dato"><span>${a}</span><span>${b}</span></div>`;

function mostrarFicha(f) {
  const ha = f.properties.ha;
  const n = contarDiques(f.geometry);
  $('#ficha-cuerpo').innerHTML = '<h3>Polígono de impacto</h3>' +
    fila('Superficie', num(ha, 2) + ' ha') +
    fila('Píxeles Sentinel-2', num(Math.round(ha * 100))) +
    (n === null ? '' : fila('Diques registrados', num(n))) +
    (n ? fila('Densidad', num(n / ha, 2) + ' /ha') : '');
  $('#ficha').hidden = false;
}

/* ---------------------------------------------------------------- panel */

function construirCapas() {
  const cont = $('#capas');
  cont.innerHTML = '';
  CAPAS.forEach((c) => {
    const ids = c.capas || [c.id];
    if (!ids.some((id) => mapa.getLayer(id))) return;
    const l = crear('label', 'capa');
    const chk = crear('input');
    chk.type = 'checkbox';
    chk.checked = c.visible;
    chk.addEventListener('change', () => {
      const vis = chk.checked ? 'visible' : 'none';
      ids.forEach((id) => mapa.getLayer(id) && mapa.setLayoutProperty(id, 'visibility', vis));
      if (c.id === 'impacto' && !chk.checked) $('#ficha').hidden = true;
      if (c.id === 'cobertura') $('#leyenda-cobertura').hidden = !chk.checked;
    });

    const m = crear('span', 'muestra');
    if (c.hueco) { m.style.background = 'transparent'; m.style.border = '1.5px solid ' + c.color; }
    else m.style.background = c.color;

    const t = crear('span'); t.textContent = c.rotulo;
    const n = crear('span', 'conteo'); n.textContent = c.n ? num(c.n) : '';
    l.append(chk, m, t, n);
    cont.appendChild(l);
  });
}

function construirNotaHex() {
  const hx = metricas && metricas.hexagonos;
  const el = $('#nota-hex');
  if (!hx || !el) return;
  el.innerHTML =
    `Los diques se agrupan en <strong>hexágonos</strong> mientras se mira de lejos
     (${hx.grueso.celdas} celdas de ${hx.grueso.resolucion === 7 ? '5,2' : '0,7'}&nbsp;km²,
     luego ${hx.fino.celdas} más finas). <strong>Al acercarse aparecen los
     ${num(806)} diques individuales</strong>, porque juntos se amontonan y no se leen.`;
}

const DOC_TITULOS = {
  ubicacion: ['Mapa de ubicación de castoreras',
              'Bosque nativo y uso de la tierra 2025, con los diques y el daño ' +
              'digitalizado sobre la base CONAF–CIREN.'],
  teselacion: ['Teselación hexagonal con tablas proyectadas',
               'El mismo territorio agregado en hexágonos de 1,4 ha ' +
               '(150 m de diámetro), clasificados por número de castoreras.'],
  satelital: ['Imágenes satelitales',
              'Composición en falso color: el bosque sano aparece oscuro y el ' +
              'daño por anegamiento, en tonos rosados.'],
};

function construirDocumentos() {
  const docs = metricas && metricas.documentos;
  const cont = $('#documentos');
  if (!docs || !cont) return;
  cont.innerHTML = docs.map((d) => {
    const [titulo, nota] = DOC_TITULOS[d.clave] || [d.clave, ''];
    // El peso se anuncia: son pliegos de 65 x 90 cm y uno pesa 18 MB, asi que
    // conviene saber lo que se esta por descargar antes de pulsar.
    return `<a class="doc" href="${v(d.archivo)}" target="_blank" rel="noopener">
      <img src="${v(d.miniatura)}" alt="" loading="lazy">
      <span class="doc-txt">
        <strong>${titulo}</strong>
        <em>${nota}</em>
        <span class="doc-meta">PDF · ${d.mm[0]} × ${d.mm[1]} mm · ${String(d.mb).replace('.', ',')} MB</span>
      </span>
    </a>`;
  }).join('');
}

function construirLeyendaCobertura() {
  const cob = metricas && metricas.cobertura;
  const cont = $('#leyenda-cobertura');
  if (!cob || !cont) return;
  cont.innerHTML = '<span class="etiqueta">Clases MapBiomas</span>' +
    '<div class="clases">' +
    cob.leyenda.map((c) =>
      `<span><i style="background:#${c.color}"></i>${c.clase}</span>`).join('') +
    '</div>';
  cont.hidden = false;
}

function construirSitios(g) {
  const cont = $('#sitios-botones');
  cont.innerHTML = '';
  const anadir = (nombre, geom, titulo) => {
    const b = crear('button');
    b.textContent = nombre;
    if (titulo) b.title = titulo;
    b.addEventListener('click', () => {
      const bb = new maplibregl.LngLatBounds();
      const rec = (c) => Array.isArray(c[0]) ? c.forEach(rec) : bb.extend(c);
      rec(geom.coordinates);
      const red = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      mapa.fitBounds(bb, { padding: 50, duration: red ? 0 : 900 });
    });
    cont.appendChild(b);
  };
  if (geo.timaukel) anadir('Timaukel', geo.timaukel.features[0].geometry, 'Comuna completa');
  g.features.forEach((f) => anadir(
    f.properties.nombre.replace(' — área de estudio', ''), f.geometry, f.properties.nota || ''));
}

function tarjetas(datos) {
  return datos.map((d) =>
    `<div class="cifra${d.destaca ? ' destaca' : ''}">
       <div class="valor">${d.v}${d.u ? `<span class="unidad">${d.u}</span>` : ''}</div>
       <div class="rotulo">${d.r}</div></div>`).join('');
}

function construirCifras() {
  const p = metricas.paisaje;
  $('#cifras').innerHTML = tarjetas([
    { v: num(p.diques), r: 'Diques registrados' },
    { v: num(p.poligonos), r: 'Polígonos de impacto' },
    { v: num(p.impacto_ha, 0), u: 'ha', r: 'Superficie impactada' },
    { v: num(p.fraccion_impactada * 100, 1), u: '%', r: 'Del área de estudio', destaca: true },
    { v: num(p.densidad_diques_km2, 2), u: '/km²', r: 'Densidad de diques' },
    { v: num(p.impacto_mediana_ha, 2), u: 'ha', r: 'Polígono mediano' },
  ]);

  const t = metricas.contexto_territorial;
  $('#nota-territorio').innerHTML = t
    ? `La comuna de Timaukel abarca <strong>${num(t.comuna_km2)}&nbsp;km²</strong>. El área de
       estudio son ${num(t.estudio_km2, 2)}&nbsp;km²: <strong>${num(t.fraccion_con_datos * 100, 2)}&nbsp;%
       de la comuna</strong>. Fuera de ese recuadro no hay datos en este sitio.`
    : 'Las superficies salen de la geometría, no del campo <code>Ha</code> del archivo original.';
}

function construirProblema() {
  $('#cifras-problema').innerHTML = tarjetas([
    { v: '1946', r: 'Introducción en Tierra del Fuego' },
    { v: '20', r: 'Individuos iniciales (10 parejas)' },
    { v: '70–110', u: 'mil', r: 'Población actual estimada', destaca: true },
    { v: '23.000', u: 'ha', r: 'Bosque nativo invadido' },
    { v: '62,8', u: 'MM US$', r: 'Pérdida en madera destruida' },
    { v: '69,6', u: 'MM US$', r: 'Proyección a 20 años' },
  ]);
  $('#nota-problema').innerHTML =
    'En Chile y Argentina el castor <strong>no tiene depredadores naturales</strong>, por lo que ' +
    'se ha reproducido como en ningún otro lugar. Fuente: Universidad de Chile / Proyecto GEF ' +
    'Castor del Ministerio del Medio Ambiente.';
}

function construirVecindad() {
  const v = metricas.vecindad, f = v.fraccion || {};
  $('#vecindad').innerHTML =
    `<div class="cifras" style="margin-bottom:13px">
       <div class="cifra"><div class="valor">${num(v.mediana_m, 1)}<span class="unidad">m</span></div>
         <div class="rotulo">Mediana al más cercano</div></div>
       <div class="cifra"><div class="valor">${num(v.min_m, 1)}<span class="unidad">m</span></div>
         <div class="rotulo">Mínimo observado</div></div></div>` +
    [['Con vecino a ≤ 100 m', f['100']], ['Con vecino a ≤ 150 m', f['150']],
     ['Con vecino a ≤ 500 m', f['500']]].map(([r, val]) => `
      <div class="barra-dato">
        <div class="fila"><span>${r}</span><span>${num(val * 100, 1)} %</span></div>
        <div class="pista"><div class="relleno" style="width:${val * 100}%"></div></div>
      </div>`).join('');
}

/* ---------------------------------------------------------- ilustraciones */

function ilustracionCorte() {
  const W = 360, H = 168, suelo = 118, et = W / 4;
  const s = lienzo(W, H, 'Secuencia de transformación del bosque por el castor');

  const etapas = [
    { t: 'Bosque en pie', c: 'Bosque', col: COLOR.bosque },
    { t: 'Dique y anegamiento', c: 'Humedal', col: COLOR.impacto },
    { t: 'Árboles muertos', c: 'Matorral', col: COLOR.muerto },
    { t: 'Vega herbácea', c: 'Estepa', col: COLOR.sitio },
  ];

  etapas.forEach((e, i) => {
    const x0 = i * et;
    if (i % 2) s.appendChild(nodo('rect', { x: x0, y: 8, width: et, height: H - 8, fill: '#FFFFFF', opacity: 0.02 }));
    s.appendChild(nodo('line', { x1: x0, y1: suelo, x2: x0 + et, y2: suelo, stroke: '#3A4A52', 'stroke-width': 1.2 }));
    s.appendChild(nodo('text', { x: x0 + et / 2, y: H - 20, 'text-anchor': 'middle', fill: '#D8D6CF', 'font-size': 8.5 }, e.t));
    s.appendChild(nodo('text', { x: x0 + et / 2, y: H - 7, 'text-anchor': 'middle', fill: e.col, 'font-size': 8, 'font-weight': '600' }, e.c));
    if (i < 3) s.appendChild(nodo('path', {
      d: `M${x0 + et - 7} ${H - 32} l5 4 -5 4`, fill: 'none', stroke: '#8C8A83', 'stroke-width': 1.2 }));
  });

  const arbol = (x, alto, vivo) => {
    s.appendChild(nodo('line', { x1: x, y1: suelo, x2: x, y2: suelo - alto,
      stroke: vivo ? '#5A4632' : COLOR.muerto, 'stroke-width': 1.8 }));
    if (vivo) {
      s.appendChild(nodo('path', {
        d: `M${x - 9} ${suelo - alto + 6} L${x} ${suelo - alto - 11} L${x + 9} ${suelo - alto + 6} Z`,
        fill: COLOR.bosque, opacity: 0.92 }));
    } else {
      [-5, 5].forEach((d) => s.appendChild(nodo('line', {
        x1: x, y1: suelo - alto + 3, x2: x + d, y2: suelo - alto - 4,
        stroke: COLOR.muerto, 'stroke-width': 1.1 })));
    }
  };

  [16, 40, 64].forEach((x, k) => arbol(x, 36 + k * 4, true));

  const x2 = et;
  s.appendChild(nodo('rect', { x: x2 + 6, y: suelo - 17, width: et - 30, height: 17, fill: COLOR.impacto, opacity: 0.55 }));
  s.appendChild(nodo('path', { d: `M${x2 + et - 24} ${suelo} l6 -21 6 21 Z`, fill: COLOR.dique }));
  s.appendChild(nodo('text', { x: x2 + et - 18, y: suelo - 26, 'text-anchor': 'middle',
    fill: COLOR.dique, 'font-size': 7.5, 'font-weight': '600' }, 'dique'));
  [x2 + 18, x2 + 38].forEach((x) => arbol(x, 30, false));

  const x3 = et * 2;
  s.appendChild(nodo('rect', { x: x3 + 4, y: suelo - 5, width: et - 10, height: 5, fill: COLOR.impacto, opacity: 0.3 }));
  [14, 32, 50, 68].forEach((d) => arbol(x3 + d, 26 + (d % 11), false));

  const x4 = et * 3;
  for (let d = 8; d < et - 6; d += 6) {
    s.appendChild(nodo('path', { d: `M${x4 + d} ${suelo} q2 -7 4 -9`,
      fill: 'none', stroke: COLOR.sitio, 'stroke-width': 1.2 }));
  }

  $('#il-corte').appendChild(s);
}

function ilustracionComportamiento() {
  const W = 360, H = 96, p = W / 4, base = 56;
  const s = lienzo(W, H, 'Secuencia de construcción de diques');
  const pasos = ['Madriguera en el cauce', 'Tala con incisivos', 'Dique represa el agua', 'Troncos esparcidos'];

  pasos.forEach((t, i) => {
    const x = i * p + p / 2;
    s.appendChild(nodo('line', { x1: i * p + 8, y1: base, x2: i * p + p - 8, y2: base,
      stroke: '#3A4A52', 'stroke-width': 1 }));
    const corte = t.lastIndexOf(' ', 17);
    const lineas = t.length > 17 && corte > 0 ? [t.slice(0, corte), t.slice(corte + 1)] : [t];
    lineas.forEach((l, k) => s.appendChild(nodo('text', {
      x, y: H - 20 + k * 9, 'text-anchor': 'middle', fill: '#9A9890', 'font-size': 7.8 }, l)));
  });

  s.appendChild(nodo('rect', { x: 10, y: base - 7, width: p - 20, height: 7, fill: COLOR.impacto, opacity: 0.45 }));
  s.appendChild(nodo('path', { d: `M${p / 2 - 13} ${base - 7} q13 -17 26 0 Z`, fill: COLOR.sitio, opacity: 0.85 }));

  const c2 = p + p / 2;
  s.appendChild(nodo('line', { x1: c2, y1: base, x2: c2, y2: base - 30, stroke: '#5A4632', 'stroke-width': 2.2 }));
  s.appendChild(nodo('path', { d: `M${c2 - 10} ${base - 34} L${c2} ${base - 50} L${c2 + 10} ${base - 34} Z`, fill: COLOR.bosque }));
  s.appendChild(nodo('path', { d: `M${c2 - 5} ${base - 8} l10 -5 -10 -5`, fill: 'none', stroke: COLOR.dique, 'stroke-width': 1.6 }));

  const x3 = 2 * p;
  s.appendChild(nodo('rect', { x: x3 + 10, y: base - 13, width: p / 2, height: 13, fill: COLOR.impacto, opacity: 0.5 }));
  s.appendChild(nodo('path', { d: `M${x3 + p / 2 + 12} ${base} l7 -22 7 22 Z`, fill: COLOR.dique }));

  const x4 = 3 * p;
  [[12, -4], [28, 6], [44, -7], [58, 3]].forEach(([d, a]) => s.appendChild(nodo('line', {
    x1: x4 + d, y1: base - 3 + a / 2, x2: x4 + d + 14, y2: base - 3 - a / 2,
    stroke: COLOR.muerto, 'stroke-width': 2, 'stroke-linecap': 'round' })));

  $('#il-comportamiento').appendChild(s);
}

function ilustracionCastor() {
  // Fotografia en vez de silueta dibujada: dos intentos de SVG dieron una
  // forma irreconocible, y una foto real sirve mejor al proposito. Dominio
  // publico del Glacier National Park Service, acreditada abajo.
  const cont = $('#il-castor');
  cont.classList.add('foto');

  const img = crear('img');
  img.src = v('datos/castor.jpg');
  img.alt = 'Castor canadiense (Castor canadensis) nadando';
  // Sin lazy: son 42 KB en un panel lateral, y el diferido puede no
  // dispararse segun como el navegador trate ese contenedor con scroll.
  img.width = 720;
  img.height = 283;

  const pie = crear('div', 'pie-foto');
  pie.innerHTML =
    '<span><strong><em>Castor canadensis</em></strong> · más de 1 m · 15 a 30 kg</span>' +
    '<span class="credito">Glacier National Park Service · dominio público</span>';

  cont.append(img, pie);
}

/* -------------------------------------------------------------- graficos */

function graficoTrayectoria() {
  const d = metricas.trayectoria_cobertura;
  if (!d || !d.length) return;
  const W = 360, H = 170, ML = 30, MB = 24, MT = 10, MR = 16;
  const ax = W - ML - MR, ay = H - MB - MT;
  const s = lienzo(W, H, 'Trayectoria de cobertura dentro del impacto, 1999 a 2024');

  const a0 = d[0].anio, a1 = d[d.length - 1].anio;
  const X = (a) => ML + ((a - a0) / (a1 - a0)) * ax;
  const Y = (v) => MT + ay - (v / 80) * ay;

  [0, 20, 40, 60, 80].forEach((v) => {
    s.appendChild(nodo('line', { x1: ML, x2: W - MR, y1: Y(v), y2: Y(v), stroke: '#273238', 'stroke-width': 1 }));
    s.appendChild(nodo('text', { x: ML - 6, y: Y(v) + 3.5, 'text-anchor': 'end', fill: '#9A9890', 'font-size': 9 }, v));
  });

  if (d[0].bosque_fondo != null) {
    s.appendChild(nodo('polyline', {
      points: d.map((p) => `${X(p.anio)},${Y(p.bosque_fondo)}`).join(' '),
      fill: 'none', stroke: COLOR.bosque, 'stroke-width': 1.6,
      'stroke-dasharray': '4 3', opacity: 0.75 }));
  }

  const series = [['bosque', COLOR.bosque, 'Bosque'], ['matorral', '#9A7C5C', 'Matorral'],
                  ['estepa', '#C8B88A', 'Estepa'], ['humedal', COLOR.impacto, 'Humedal']];
  series.forEach(([k, color]) => {
    s.appendChild(nodo('polyline', {
      points: d.map((p) => `${X(p.anio)},${Y(p[k] || 0)}`).join(' '),
      fill: 'none', stroke: color, 'stroke-width': k === 'bosque' ? 2.4 : 1.7,
      'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
    if (d.length <= 8) d.forEach((p) => s.appendChild(nodo('circle', {
      cx: X(p.anio), cy: Y(p[k] || 0), r: 2.1, fill: color })));
  });

  let marcas;
  if (d.length <= 8) marcas = d.map((p) => p.anio);
  else {
    const anios = d.map((p) => p.anio);
    marcas = anios.filter((a) => a % 5 === 0);
    const lejos = (a) => marcas.every((m) => Math.abs(m - a) >= 3);
    if (lejos(anios[0])) marcas.unshift(anios[0]);
    if (lejos(anios[anios.length - 1])) marcas.push(anios[anios.length - 1]);
  }
  marcas.forEach((a) => s.appendChild(nodo('text', {
    x: X(a), y: H - 7, 'text-anchor': 'middle', fill: '#9A9890', 'font-size': 9 }, a)));

  const cont = $('#gr-trayectoria');
  cont.appendChild(s);
  const ley = crear('div', 'leyenda');
  ley.innerHTML = series.map(([, c, r]) => `<span><i style="background:${c}"></i>${r}</span>`).join('') +
    `<span><i style="background:transparent;border-top:2px dashed ${COLOR.bosque};height:0"></i>Bosque en el resto del paisaje</span>`;
  cont.appendChild(ley);
}

function graficoEnriquecimiento() {
  const d = metricas.enriquecimiento_2018 || [];
  if (!d.length) return;
  const orden = [...d].sort((a, b) => b.enriq - a.enriq);
  const max = Math.max(...orden.map((x) => x.enriq), 1);
  $('#gr-enriquecimiento').innerHTML = orden.map((f) => `
    <div class="barra-dato">
      <div class="fila"><span>${f.clase}</span>
        <span>${num(f.impacto, 1)} % vs ${num(f.fondo, 1)} % · <b>${num(f.enriq, 2)}×</b></span></div>
      <div class="pista"><div class="relleno" style="width:${(f.enriq / max) * 100}%;
        background:${f.enriq >= 1 ? '#9A7C5C' : COLOR.impacto}"></div></div>
    </div>`).join('');
}

function graficoSeparabilidad() {
  const d = metricas.separabilidad || [];
  if (!d.length) return;
  const filas = d.map((x) => ({ ...x, poder: Math.abs(x.auc - 0.5) * 2 }))
    .sort((a, b) => b.poder - a.poder);
  const max = filas[0].poder || 1;
  $('#gr-separabilidad').innerHTML = filas.map((f) => {
    const agua = f.variable === 'MNDWI';
    return `<div class="barra-dato">
      <div class="fila"><span style="${agua ? 'color:#E08A3C' : ''}">${f.variable}${agua ? ' · índice de agua' : ''}</span>
        <span>AUC ${num(f.auc, 3)}</span></div>
      <div class="pista"><div class="relleno" style="width:${(f.poder / max) * 100}%;
        background:${agua ? '#E08A3C' : COLOR.impacto}"></div></div></div>`;
  }).join('');
}

function graficoLandsat() {
  const d = metricas.serie_landsat || [];
  if (!d.length) return;
  const W = 360, H = 130, ML = 26, MB = 22, MT = 8, MR = 16;
  const ax = W - ML - MR, ay = H - MB - MT;
  const s = lienzo(W, H, 'Escenas Landsat utilizables por año, 1985 a 2024');
  const max = Math.max(...d.map((x) => x.escenas), 1), w = ax / d.length;

  [0, Math.round(max / 2), max].forEach((v) => {
    const y = MT + ay - (v / max) * ay;
    s.appendChild(nodo('line', { x1: ML, x2: W - MR, y1: y, y2: y, stroke: '#273238', 'stroke-width': 1 }));
    s.appendChild(nodo('text', { x: ML - 5, y: y + 3.5, 'text-anchor': 'end', fill: '#9A9890', 'font-size': 9 }, v));
  });

  d.forEach((p, i) => {
    const h = (p.escenas / max) * ay, sin = p.escenas === 0;
    if (sin) {
      s.appendChild(nodo('rect', { x: ML + i * w + 0.6, y: MT, width: Math.max(w - 1.2, 1),
        height: ay, fill: COLOR.dique, opacity: 0.17 }));
      s.appendChild(nodo('rect', { x: ML + i * w + 0.6, y: MT + ay - 2.5, width: Math.max(w - 1.2, 1),
        height: 2.5, fill: COLOR.dique, opacity: 0.9 }));
    } else {
      s.appendChild(nodo('rect', { x: ML + i * w + 0.6, y: MT + ay - h, width: Math.max(w - 1.2, 1),
        height: Math.max(h, 1), fill: COLOR.impacto, opacity: 0.9 }));
    }
    const r = nodo('rect', { x: ML + i * w, y: MT, width: w, height: ay, fill: 'transparent' });
    r.appendChild(nodo('title', {}, `${p.anio}: ${p.escenas} escenas`));
    s.appendChild(r);
  });

  [1985, 1995, 2005, 2015, 2024].forEach((a) => {
    const i = d.findIndex((x) => x.anio === a);
    if (i >= 0) s.appendChild(nodo('text', {
      x: ML + i * w + w / 2, y: H - 6, 'text-anchor': 'middle', fill: '#9A9890', 'font-size': 9 }, a));
  });

  const cont = $('#gr-landsat');
  cont.appendChild(s);
  const ley = crear('div', 'leyenda');
  ley.innerHTML = `<span><i style="background:${COLOR.impacto}"></i>Escenas utilizables</span>` +
    `<span><i style="background:${COLOR.dique}"></i>Año sin dato</span>`;
  cont.appendChild(ley);
}

/* ------------------------------------------------ visor de cuatro paneles */

function crearPaneles() {
  const cfg = metricas && metricas.ndvi;
  if (!cfg || paneles.length) return;
  const cont = $('#rejilla-paneles');
  cont.innerHTML = '';

  cfg.paneles.forEach((p) => {
    const caja = crear('div', 'panel-ndvi');
    const lienzoMapa = crear('div', 'lienzo');
    const et = crear('span', 'fecha-panel');
    et.textContent = new Date(p.fecha + 'T00:00:00')
      .toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
    caja.append(lienzoMapa, et);
    cont.appendChild(caja);

    // Encuadre a la extension del NDVI, no al del mapa principal: heredar su
    // zoom dejaba la imagen pequena y rodeada de negro.
    const extension = new maplibregl.LngLatBounds();
    cfg.esquinas.forEach((c) => extension.extend(c));

    const m = new maplibregl.Map({
      container: lienzoMapa, style: ESTILO_BASE,
      bounds: extension, fitBoundsOptions: { padding: 6 },
      attributionControl: false,
    });

    m.on('load', () => {
      m.addSource('ndvi', { type: 'image', url: v(p.archivo), coordinates: cfg.esquinas });
      m.addLayer({ id: 'ndvi', type: 'raster', source: 'ndvi', paint: { 'raster-opacity': 0.92 } });
      if (geo.impacto) {
        m.addSource('impacto', { type: 'geojson', data: geo.impacto });
        m.addLayer({ id: 'impacto-borde', type: 'line', source: 'impacto',
          paint: { 'line-color': COLOR.impactoBorde, 'line-width': 1.1, 'line-opacity': 0.9 } });
      }
    });

    // La bandera evita el bucle de eventos entre los cuatro paneles.
    m.on('move', () => {
      if (sincronizando) return;
      sincronizando = true;
      const c = m.getCenter(), z = m.getZoom();
      paneles.forEach((o) => { if (o !== m) o.jumpTo({ center: c, zoom: z }); });
      sincronizando = false;
    });

    paneles.push(m);
  });

  $('#leyenda-ndvi').innerHTML =
    '<span class="rot">NDVI</span>' +
    `<span class="rampa" style="background:linear-gradient(90deg,${cfg.paleta.map((c) => '#' + c).join(',')})"></span>` +
    `<span class="ext">${num(cfg.rango[0], 2)} a ${num(cfg.rango[1], 2)}</span>` +
    '<span class="nota">Verde: vegetación densa · Naranja y magenta: suelo, agua o bosque degradado</span>';
}

function cambiarVista(comparar) {
  $('#comparar').hidden = !comparar;
  $('#mapa').style.display = comparar ? 'none' : '';
  $('#ficha').hidden = true;
  $('#v-mapa').classList.toggle('activa', !comparar);
  $('#v-comparar').classList.toggle('activa', comparar);
  $('#v-mapa').setAttribute('aria-pressed', String(!comparar));
  $('#v-comparar').setAttribute('aria-pressed', String(comparar));
  // Un mapa creado mientras su contenedor estaba oculto nace con tamano cero.
  // El primer resize en el siguiente frame no siempre basta si el layout aun
  // se esta acomodando, asi que se repite una vez mas.
  const ajustar = (ms) => setTimeout(() => {
    paneles.forEach((m) => m.resize());
    if (mapa) mapa.resize();
  }, ms);
  if (comparar) {
    crearPaneles();
    requestAnimationFrame(() => paneles.forEach((m) => m.resize()));
    ajustar(260);
  } else if (mapa) {
    requestAnimationFrame(() => mapa.resize());
    ajustar(260);
  }
}

/* ----------------------------------------------------------------- inicio */

function interfaz() {
  $('#cerrar-ficha').addEventListener('click', () => { $('#ficha').hidden = true; });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#ficha').hidden = true; });
  $('#v-mapa').addEventListener('click', () => cambiarVista(false));
  $('#v-comparar').addEventListener('click', () => cambiarVista(true));

  const bt = $('#alternar-panel');
  bt.addEventListener('click', () => {
    const oculto = $('#panel').classList.toggle('oculto');
    bt.setAttribute('aria-expanded', String(!oculto));
    bt.textContent = oculto ? 'Datos' : 'Visor';
    if (mapa) mapa.resize();
    paneles.forEach((m) => m.resize());
  });
}

(async function inicio() {
  interfaz();
  ilustracionCorte();
  ilustracionComportamiento();
  ilustracionCastor();
  try {
    // Las metricas se cargan ANTES de iniciar el mapa: cargarCapas necesita
    // metricas.cobertura para montar el fondo.
    metricas = await json(v('datos/metricas.json'));
    construirDocumentos();
    construirCifras();
    construirProblema();
    construirVecindad();
    graficoTrayectoria();
    graficoEnriquecimiento();
    graficoSeparabilidad();
    graficoLandsat();
  } catch (err) {
    console.error('No se pudieron cargar las métricas:', err);
  }
  iniciarMapa();
})();
